<?php
require_once '../webapp/CB.php';
header("Content-type: text/css");
?>

/* COMMON */
body {
	border-top : 3px solid #008CD6;
	padding: 0px;
	margin:0px 2%;
	color:#444;
	}
body, TD, DIV { 
	font-family : Tahoma, Verdana, Arial, Helvetica, sans-serif; 
	color: #121212;
}

/*body { direction: rtl; unicode-bidi: embed; }
TD   { direction: rtl; unicode-bidi: embed; }
DIV  { direction: rtl; unicode-bidi: embed; }*/

/* COMMON LINKS */
a:link     { background-color: transparent; }
a:visited  { background-color: transparent; }
a:active   { background-color: transparent; }
a:hover    { background-color: transparent; }
a.noformat { text-decoration: none; color: #121212; }
a img{ border:none; }


/* CATEGORY */
.catLink        { font-weight : bold; }
.catDescription { color : #121212;  }


/* ARTICLE */
H1.articleTitle    { font-size : 1.0em; margin: 0px; }
a.articleLink      { font-weight : bold; }
a.articleLinkOther {  }  /* for other in category and related */
.articleDecription { color : #121212; }
.articleStaff      { color : #505050; 	font-size : 0.8em; }
.glossaryItem      { background-color : #F0F0F0; cursor : help; color : #CC3333; }


/* HEADER & CONTENT */	
div.content {
	background-color: #ffffff;
}

/* LOGIN LINK */
div.login { font-size : 0.8em; font-weight: bold; text-align: right; white-space : nowrap;
			padding-right: 15px; padding-bottom: 8px; }		
a.login {  }


/* NAVIGATION */
div.navigation  { color : #121212; 	background-color: #ffffff; font-size : 0.9em; }
a.navigation    { color : #121212; }


/* ARTICLE BLOCK */
a.abLink     {  }
.abBorder    { background-color : #E4E4E4;  }
.abBgr       { background-color : #FFFFFF;  font-size : 0.9em; }
.abBgrDarker { background-color : #FAFAFA;  color : #606060;  font-size : 0.9em; }


/* ATTACHMENT */
.atTitle      { font-weight : bold;  }
.atEntry      { /* font-size: 0.8;*/ }


/* FILES */
.fName        { font-size : 0.8em; }


/* TABLES */
.tdBorder     { background-color : #E4E4E4;  }
.tdTitle      { background-color : #E4E4E4; padding : 4px 4px;  border : 1px solid #D4D4D4; }
.tdSubTitle   { background-color : #EFEFEF; padding : 4px 4px;  border : 1px solid #DADADA; }

.trLighter    { background-color : #FFFFFF; }
.trDarker     { background-color : #F4F4F4; }
.trMoreDarker { background-color : #DADADA; }


/*  FORMS  */
.trForm         { background-color : #FAFAFA; }
.tdFormCaption  { background-color : #F4F4F4;  text-align: right; width: 150px; }

input, select   { font-size : 12px;  margin : 2px;  padding: 2px; }
input.text      { width : 110px; }
input.shortText { width : 80px; }
input.longText  {  width : 250px;   }

.button         { width : 150px; }
.colorInput     { background-color : #F5F4ED; }
.requiredSign   { color : #C40000; font-weight : bold; }
.formComment    { font-size : 0.9em; }


/*  OTHER  */
.copyright      { font-size : 0.8em; }
.pageByPage     { font-size : 0.9em; }
.smallerText    { font-size : 0.9em; }
.nowrap         { white-space: nowrap; }
.space          { padding-bottom: 5px; }
.less_space     { padding-bottom: 2px; }
.info           { background-color : #FFFFE1; border : 1px solid #8592A2; padding: 10px;}

.fright         { float: right; }
.fleft          { float: left; }


/* HEADER & CONTENT */	
a.header  {
	text-decoration : none;
	font-size : 1.7em;
	font-weight: bold;
	}
div.header { 
	padding: 15px;
	text-align: left;
	border-bottom:2px solid #DDD;
	background-color: #008CD6;
}
p.header {
	color: #FFF;
}

/* LOGIN */	
div.login { font-size : 0.9em; font-weight: bold; text-align: right; 
			padding-right: 15px;  color: #FFFFFF; }
a.login {  color: #FFFFFF; }

body {  font-size : 75%;  }
TD   {  font-size : 1.0em;  }
DIV  {  font-size : 1.0em; }

.textBlock { line-height : 150%; }

.admin td { background:#F5F5F5;}

<?php echo $GLOBALS['topic_status_css']; ?>