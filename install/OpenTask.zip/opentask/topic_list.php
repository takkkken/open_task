<?php

/**
 * topic_list.php
 *
 * @copyright  2004-2007 CYBRiDGE
 * @license    CYBRiDGE 1.0
 */

require_once './webapp/CB.php';

$db = new CB_DB;

//管理者以外は閲覧不可にする
if(!$GLOBALS['user']['admin']) $where[] = $where[] = "is_admin = 0";

if($_GET["mode"]!=all AND !$_GET["topic_status"]){
	if($GLOBALS['topic_status_hidden']){
		foreach($GLOBALS['topic_status_hidden'] as $_topic_status_hidden)
		$where[] = "topic_status NOT LIKE '{$_topic_status_hidden}'";
	}else{
		$where[] = "topic_status NOT LIKE '完了'";
		$where[] = "topic_status NOT LIKE '作業終了'";
	}
}




//担当者検索
if($_GET["user"]!="all" && $_GET["user"]){
	$where[] = "topic_to LIKE '%{$_GET["user"]}%'";
}

//カテゴリ検索
if($_GET["topic_type"]){
	$where[] = "topic_type = '{$_GET["topic_type"]}'";
}

//状態検索
if($_GET["topic_status"]){
	$where[] = "topic_status = '{$_GET["topic_status"]}'";
}

//キーワード検索
if($_GET["q"]){
	$where[] = "(topic_title LIKE '%{$_GET["q"]}%' OR topic_contents LIKE '%{$_GET["q"]}%')";
}

//ソート（期限）
switch($_GET["topic_due_datetime"]){
	case "最新順" :
		$order = "topic_due_datetime DESC";
		break;
	case "古い順" :
		$order = "topic_due_datetime ASC";
		break;
	default :
		$order = "modified_time DESC";
	break;
}

if($where){
        $whereSQL = "WHERE is_deleted=0 AND ".implode(" AND ",$where);
}
$data = $db->GetAll("SELECT * FROM topic {$whereSQL} ORDER BY {$order}");

///////////////////////////////////////////////////
// RSSの出力
///////////////////////////////////////////////////

if($_GET["mode"]=="rss"){
	require_once("XML/Serializer.php");

	$xmlData = array();
	foreach($data AS $val){
		$xmlData[] = array(
		      'title' => $val['topic_title'], 
		      'link' => SITE_URL . 'topic_detail.php?topic_id=' . $val['topic_id'], 
		      'pubDate' => $val['modified_time'], 
		      'description' => $val['topic_contents'], 
		);
	}
	$data = array( 
	  'channel' => array( 
	    'title' => PJ_NAME, 
	    'link'  => SITE_URL , 
	    'description' => '[進捗管理システム]' . PJ_NAME, 
	    'language' => 'ja-jp', 
	    'pubDate' => $xmlData[0]['pubDate'],
	    ) + $xmlData,
	); 
	$options = array( 
	  XML_SERIALIZER_OPTION_INDENT => "\t", 
	  XML_SERIALIZER_OPTION_XML_ENCODING => 'UTF-8', 
	  XML_SERIALIZER_OPTION_XML_DECL_ENABLED => TRUE, 
	  XML_SERIALIZER_OPTION_ROOT_NAME => 'rss', 
	  XML_SERIALIZER_OPTION_ROOT_ATTRIBS => array('version' => '2.0'), 
	  XML_SERIALIZER_OPTION_DEFAULT_TAG => 'item' 
	); 

	$serializer = new XML_Serializer($options); 
	$serializer->serialize($data); 
	$result = $serializer->getSerializedData(); 

	header("Content-Type: text/xml; charset=utf-8"); 
	echo $result;
	exit();
}

///////////////////////////////////////////////////
// HTMLの出力
///////////////////////////////////////////////////

include_once 'skin/inc/header.inc';
?>
<p class="fright">
<?php foreach($GLOBALS['topic_status'] AS $status_key=>$status_val){
	$count = getStatusCount($status_key);
	$total = $total + $count; 
?>
<a href="<?=$_SERVER["PHPSELF"]?>?topic_status=<?=urlencode($status_key)?>"><?=substr($status_key,0,3)?>(<?=$count?>)</a>
<? } ?>
<a href="./?mode=all">全(<?=$total?>)</a>
</p>
<p><?=count($data);?>件を表示しています</p>
<table width="100%">
<tr valign="top">
	<td width="50%"><table border=0 width="100%" cellpadding="11" cellspacing="1" class="tdBorder">
<tr class="tdTitle">
	<td class="tdTitle" colspan="11"><b>課題リスト</b></td>
</tr>
<tr class="trMoreDarker">
	<td nowrap>ID</td>
	<td nowrap>種別</td>
	<td nowrap>状態</td>
	<td nowrap>期限</td>
	<td nowrap>更新</td>
	<td nowrap>担当者</td>
	<td nowrap>更新者</td>
	<td>タイトル</td>
	<td>概要</td>
	<td>添付</td>
	<td>　</td>
</tr>

<?php foreach($data as $val){ ?>

<tr class="trLighter<?=statusColor($val["topic_status"])?><?php if($val["is_admin"]) echo " admin"; ?>">
	<td nowrap><?=$val["topic_id"]?></td>
	<td nowrap>
		<?php if($GLOBALS['topic_type'][$val["topic_type"]]){ ?>
		<img src="./skin/images/icon/<?=$GLOBALS['topic_type'][$val["topic_type"]]?>" alt="<?=$val["topic_type"]?>" width="16\" height="16" /></td>
		<?php }else{ ?>
			<?=$val["topic_type"]?>
		<? } ?>
	<td nowrap><b style="color:<?=$GLOBALS['topic_status'][$val["topic_status"]]?>;"><?=$val["topic_status"]?></b></td>
	<td nowrap><?=changeDate($val["topic_due_datetime"])?></td>
	<td nowrap><?=leftTime($val["modified_time"])?></td>
	<td nowrap><?=showTopicTo($val["topic_to"])?></td>
	<td nowrap><?=$val["modified_user"]?></td>
	<td nowrap><a href="topic_detail.php?topic_id=<?=$val["topic_id"]?>"><?=cutView($val["topic_title"],15)?> (<?=$val["topic_res_count"]?>)</a>
	<td width="80%"><?=cutView($val["topic_contents"],50)?></td>
	<td nowrap><?=downloadIcon($val)?></td>
	<td nowrap><a href="topic_delete.php?act=list&topic_id=<?=$val["topic_id"]?>" onClick="res=confirm('削除します。');if(res==false){return false;}">削除</a></td>
</tr>
<?php } ?>

</table>


<?php
include_once 'skin/inc/footer.inc';
