<?php

/**
 * topic_update.php
 *
 * @copyright  2012 Y.Suzuki
 * @license    BSD
 */

require_once './webapp/CB.php';
require_once './js/liveDate.php';
require_once './webapp/lib/public_holiday.php';
$db = new CB_DB;

if(!$_POST["topic_title"] && !$_POST["topic_contents"]){
	if(!$_GET["topic_id"]){
		httpRedirect("./");
	}else{
		$data= $db->GetRow("SELECT * FROM topic WHERE is_deleted=0 AND topic_id = {$_GET["topic_id"]}");
		if($data["topic_due_datetime"]!=null){
			$topic_due_datetime_year  = mb_substr($data["topic_due_datetime"],0,4,utf8);
			$topic_due_datetime_month = ereg_replace("^0+", "", mb_substr($data["topic_due_datetime"],5,2,utf8));
			$topic_due_datetime_date   = ereg_replace("^0+", "", mb_substr($data["topic_due_datetime"],8,2,utf8));
			$topic_due_datetime_day   = change_day($data["topic_due_datetime"]);
		}else{
			unset($data["topic_due_datetime"]);
		}
	}
}else{
	$data = $_POST;
	unset($data["_setDate"]);
	unset($data["_submit"]);
	unset($data["_choice_user_id"]);

	$data["topic_to"] = @implode(",",$_POST["topic_to"]);	
	
	if($data["date"]){
		$data["date"]["month"] = sprintf("%02d",$data["date"]["month"]);
		$data["date"]["date"]  = sprintf("%02d",$data["date"]["date"]);
		$data["topic_due_datetime"]   = "{$data["date"]["year"]}-{$data["date"]["month"]}-{$data["date"]["date"]} 00:00:00";
		unset($data["date"]);
	}else{
		$data["topic_due_datetime"] = null;
	}
	if(! $data["is_admin"]){
		$data["is_admin"] = 1;
	}
	$db->Update("topic",$data,'topic_id='. $_POST["topic_id"]);
	
	if($data["topic_to"]){
		$data["subject"] = "[".PJ_NAME."] ({$data["topic_type"]}){$data["topic_title"]}";
		sendMail($users,"topic_update",$data+$_POST);
	}
	
	httpRedirect("topic_detail.php?topic_id=". $_POST["topic_id"]);

}

include_once 'skin/inc/header.inc';

?>

<div class="tdSubTitle">
	<div>
		<b>課題の編集</b>
	</div>
</div>

<div id="comment_form">

	<form action="<?=$_SERVER["PHP_SELF"]?>" method="post"
		enctype="multipart/form-data" name="form" id="form"
		onSubmit="return check_update(<?=$GLOBALS['user']['admin']?>);">
		<table border="0" width="100%" cellpadding="5" cellspacing="0">


			<tr class="trForm">
				<td class="tdFormCaption">名前:</td>
				<td><?=$GLOBALS['user']['user_name']?>&nbsp;&lt;<?=$GLOBALS['user']['user_mail']?>&gt;</td>
			</tr>

			<tr class="trForm">
				<td class="tdFormCaption"><span class="requiredSign">*</span> タイトル:</td>
				<td><input name="topic_title" type="text"
					value="<?=$data["topic_title"]?>" id="title" style="width: 300px;" />
				</td>
			</tr>

			
				<tr class="trForm">
					<td class="tdFormCaption"><span class="requiredSign">*</span> 期限:</td>
					<td><span id="HTML_AJAX_LOADING"></span> 
        			<?php
						if(!$data["topic_due_datetime"]){
					        print '<label><input type="radio" name="_setDate" checked="checked" onclick="set_date(\'date\',\'disabled\');" />設定しない</label>';
        					print '<label><input type="radio" name="_setDate" onclick="set_date(\'date\',\'\');get_date(\'date\');" />設定する</label>';
						}else{
					        print '<label><input type="radio" name="_setDate" onclick="set_date(\'date\',\'disabled\');" />設定しない</label>';
        					print '<label><input type="radio" name="_setDate" checked="checked" onclick="set_date(\'date\',\'\');get_date(\'date\');" />設定する</label>';
						}
					?>
        			<?php
						if(!$data["topic_due_datetime"]){
							print '<select name="date[year]" id="date[year]" onchange="get_date(\'date\');" disabled="disabled">';
						}else{
							print '<select name="date[year]" id="date[year]" onchange="get_date(\'date\');">';
						}
					?>
			        <?php
			        for($i=date("Y");$i<date("Y")+10;$i++){
			                $selected = "";
			                if($i == $topic_due_datetime_year){
			                	$selected = " selected=\"selected\"";
			                	$j = $topic_due_datetime_year;
			                	echo "<option value=\"{$j}\"{$selected}>{$j}年</option>";
			        		}else{
			                	echo "<option value=\"{$i}\">{$i}年</option>";
			        		}
			        }
			        ?>
			        </select>
        			<?php
						if(!$data["topic_due_datetime"]){
							print '<select name="date[month]" id="date[month]" onchange="get_date(\'date\');" disabled="disabled">';
						}else{
							print '<select name="date[month]" id="date[month]" onchange="get_date(\'date\');">';
						}
					?>
			        <?php
			        for($i=1;$i<13;$i++){
			                $selected = "";
			                if($data["topic_due_datetime"]){
				                if($i == $topic_due_datetime_month){
				                	$selected = " selected=\"selected\"";
				                }
			                }else{
				                if($i == date("m")){
					                $selected = " selected=\"selected\"";
				                }
			        		}
					        echo "<option value=\"{$i}\"{$selected}>{$i}月</option>";
			         }
			        ?>
					</select>
					<span id="date">
        			<?php
						if(!$data["topic_due_datetime"]){
							/*
							 * print '<option value="'.date("d").'">'.date("j").'日 ('.change_day(date("Y-m-d H:i:s")).')</option>';
							 */
							print '<select name="date[date]" id="date[date]" disabled="disabled">';
							
               				$str = '<option value="'.date("d").'"';
							if(date('w')==6){
								$str .= ' style="background-color:#CCFFFF"';
							}else if(date('w')==0){
								$str .= ' style="background-color:#FFCCCC"';
								
							}
							$str .= '>'.date("j").'日 ('.change_day(date("Y-m-d H:i:s")).')</option>';
							print $str;
						}else{
							print '<select name="date[date]" id="date[date]">';
               				print '<option value="'.$topic_due_datetime_date.'">'.$topic_due_datetime_date.'日 ('.$topic_due_datetime_day.')</option>';
						}
					?>
        </select>
        </td>
				</tr>
			
			<tr class="trForm" valign="top">
				<td valign="top" class="tdFormCaption"><span class="requiredSign">*</span>
					コメント: <br /> <span class="formComment nowrap"></span>
				</td>
				<td valign="top">
					<p style="color:red;">URLなど状況がわかるものをできる限り記入をお願いします</p>
					<textarea cols="60" rows="4" name="topic_contents" id="comment" style="width: 100%; height: 150px;"><?=$data["topic_contents"]?></textarea>
				</td>
			</tr>


  			<tr class="trForm">
				<td class="tdFormCaption">担当者:</td>
				<td><select class="" size="5" name="topic_to[]" id="topic_to" title="担当者" multiple>
				<?php
					if($data["topic_to"]){
						$topic_to_users=explode(',',$data["topic_to"]);
						foreach($topic_to_users AS $val){ 
							print '<option value="'.$val.'" selected>'.$val.'</option>';
						}
					}
					print '<option></option>';
						?>
				</select>
				<input type="button" value="追加" onClick="add_select('_choice_user_id','topic_to')" />
				<input type="button" value="削除" onClick="remove_select('topic_to')" />
				<select name="_choice_user_id[]" id="_choice_user_id" size="5" multiple>
					<?php if($GLOBALS['user']['user_name'] != $topic["modified_user"]){ ?>
						<?php foreach($GLOBALS['topic_to_user'] AS $val){ ?>
							<option value="<?=$val["user_name"]?>"><?=$val["user_name"]?></option>
						<?php } ?>
						<?php foreach($GLOBALS['topic_to'] AS $key=>$val){ ?>
							<option value="<?=$key?>"><?=$key?></option>
						<?php } ?>
					<?php }else{ ?>
						<option value="<?=$GLOBALS['user']['user_name']?>"><?=$GLOBALS['user']['user_name']?></option>
						<?php foreach($GLOBALS['topic_to_user'] AS $val){ ?>
							<option value="<?=$val["user_name"]?>"><?=$val["user_name"]?></option>
						<?php } ?>
						<?php foreach($GLOBALS['topic_to'] AS $key=>$val){ ?>
							<option value="<?=$key?>"><?=$key?></option>
						<?php } ?>
					<?php } ?>
								<option value=""></option>
							</select>
							</td>
						</tr>

			<tr class="trForm">
				<td class="tdFormCaption">種別:</td>
				<td><select name="topic_type">
						<option value="">▼種別</option>
									<?php
				foreach($GLOBALS['topic_type'] AS $key=>$val){ 
					if($key!=$data['topic_type']){
						print '<option value="'.$key.'">'.$key.'</option>';
					}else{
						print '<option selected value="'.$key.'">'.$key.'</option>';
					}
				}
				?>
				</select>
				</td>
			</tr>

			<?php if($GLOBALS['user']['admin'] && !$GLOBALS['not_need_client_system']){ ?>
			<tr class="trForm">
				<td class="tdFormCaption">クライアント公開設定:</td>
				<td>
					<p style="color: red;">非公開設定時は管理者以外閲覧不可。</p> <select
					name="is_admin" id="is_admin">
						<option value="">公開設定</option>
						<?php if ($data['is_admin']==0){
							print '<option value="0" selected>公開</option>';
							print '<option value="1">非公開</option>';
						}else{
							print '<option value="0">公開</option>';
							print '<option value="1" selected>非公開</option>';
							}
						?>
				</select>
				</td>
			</tr>
			<?php } ?>

			<tr>
				<td></td>
				<td><div>
						<br />
					</div> <input type="submit" name="_submit" id="submit" value="更新"
					class="button" />
				</td>
			</tr>
		</table>
		<input type="hidden" name="topic_id" value="<?=$data["topic_id"]?>" />
	</form>
	<?php
include_once 'skin/inc/footer.inc';


//期限が設定されている場合日付リストを読み込む
if($data["topic_due_datetime"]){
	echo '<script language=javascript>get_date(\'date\');</script>';
}
