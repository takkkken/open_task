CREATE DATABASE opentask DEFAULT CHARACTER SET UTF8;

CREATE TABLE topic (
  topic_id int(11) NOT NULL auto_increment,
  user_name varchar(255) NOT NULL,
  topic_to varchar(255) NULL,
  topic_title varchar(255) NULL,
  topic_contents text NOT NULL,
  topic_type varchar(255),
  topic_due_datetime datetime NULL,
  topic_res_count int(10) NOT NULL default '0',
  topic_status varchar(255) NOT NULL,
  file_name text NULL,
  modified_user varchar(255) NULL,
  is_admin int(1) NOT NULL default '0',
  is_deleted int(1) NOT NULL default '0',
  modified_time datetime NOT NULL default '0000-00-00 00:00:00',
  registered_time datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (topic_id)
);


CREATE TABLE res (
  res_id int(11) NOT NULL auto_increment,
  topic_id int(11) NOT NULL ,
  topic_status varchar(255) NOT NULL,
  user_name varchar(255) NOT NULL,
  res_title varchar(255) NULL,
  res_contents text NOT NULL,
  authority varchar(255),
  file_name text NULL,
  modified_user varchar(255) NULL,
  is_deleted int(1) NOT NULL default '0',
  modified_time datetime NOT NULL default '0000-00-00 00:00:00',
  registered_time datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (res_id)
);

CREATE TABLE modified_user_count (
  user_name varchar(255) NOT NULL unique,
  modified_count int(11) NOT NULL default '1'
);
